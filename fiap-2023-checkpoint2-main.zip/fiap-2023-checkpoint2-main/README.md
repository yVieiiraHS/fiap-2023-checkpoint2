Integrantes:

Vitor Pfitzenmeier RM87536 - https://github.com/Vitorpfi/fiap-2023-checkpoint2

Guilherme Vieira RM87836 - 
